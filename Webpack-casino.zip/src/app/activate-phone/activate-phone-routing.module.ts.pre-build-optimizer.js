import { Routes } from '@angular/router';
import { ActivatePhoneComponent } from './activate-phone.component';
var ɵ0 = {
    title: 'Activation',
};
export var routes = [
    {
        path: ':phone',
        component: ActivatePhoneComponent,
        data: ɵ0,
    },
];
var ActivatePhoneRoutingModule = /** @class */ (function () {
    function ActivatePhoneRoutingModule() {
    }
    return ActivatePhoneRoutingModule;
}());
export { ActivatePhoneRoutingModule };
export { ɵ0 };
