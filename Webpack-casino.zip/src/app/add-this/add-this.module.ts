import { NgModule } from '@angular/core';

import { AddThisService } from './add-this.service';

@NgModule({
  providers: [
    AddThisService,
  ],
})
export class AddThisModule { }
